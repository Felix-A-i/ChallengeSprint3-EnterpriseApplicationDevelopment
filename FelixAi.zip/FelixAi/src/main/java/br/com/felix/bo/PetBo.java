package br.com.felix.bo;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import br.com.felix.model.Categoria;
import br.com.felix.model.Dono;
import br.com.felix.model.GeneroPet;
import br.com.felix.model.Pet;
import br.com.felix.model.Raca;
import br.com.felix.repository.CategoriaRepository;
import br.com.felix.repository.DonoRepository;
import br.com.felix.repository.PetRepository;
import br.com.felix.repository.RacaRepository;
import net.sf.json.JSONObject;

public class PetBo {
	private PetRepository petRepository;
	private RacaRepository racaRepository;
	private CategoriaRepository categoriaRepository;
	private DonoRepository donoRepository;
	
	public PetBo(PetRepository petRepository, RacaRepository racaRepository, CategoriaRepository categoriaRepository, DonoRepository donoRepository) {
		this.petRepository = petRepository;
		this.racaRepository = racaRepository;
		this.categoriaRepository = categoriaRepository;
		this.donoRepository = donoRepository;
	}

	public Pet salvarPet(Pet p) {
		return this.petRepository.save(p);
	}

	public Pet alteraPet(JSONObject novoPet) throws ParseException {
		Integer idPet = novoPet.getInt("idPet");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Pet petAlterar = this.petRepository.findByIdPet(idPet);
		petAlterar.setNome(novoPet.getString("nomePet"));
		petAlterar.setPeso(novoPet.getDouble("pesoPet"));
		Raca raca = racaRepository.findByIdRaca(novoPet.getInt("idRaca"));
		petAlterar.setRaca(raca);
		petAlterar.setGenero((novoPet.getInt("generoPet") == 1 ? GeneroPet.FEMEA : GeneroPet.MACHO));
		petAlterar.setDtNascPet(sdf.parse(novoPet.getString("dtNascPet")));
		Categoria cat = categoriaRepository.findByIdCategoria(novoPet.getInt("idCategoria"));
		petAlterar.setCategoria(cat);
		Dono dono = this.donoRepository.findByIdDono(novoPet.getInt("idDono"));
		petAlterar.setDono(dono);
		
		return this.petRepository.save(petAlterar);

	}
	public void deletePet(Pet p) {
		 this.petRepository.delete(p);
	}
	

}
