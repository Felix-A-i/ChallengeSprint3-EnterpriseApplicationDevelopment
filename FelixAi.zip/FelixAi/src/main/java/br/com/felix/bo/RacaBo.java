package br.com.felix.bo;


import javax.validation.Valid;

import br.com.felix.dto.LoginDto;
import br.com.felix.model.Categoria;
import br.com.felix.model.Raca;
import br.com.felix.repository.CategoriaRepository;
import br.com.felix.repository.RacaRepository;
import net.sf.json.JSONObject;

public class RacaBo {
	
	private RacaRepository racaRepository;
	private CategoriaRepository categoriaRepository;
	
	public RacaBo(RacaRepository racaRepository, CategoriaRepository categoriaRepository) {
		this.racaRepository = racaRepository;
		this.categoriaRepository = categoriaRepository;
	}
	
	public Raca salvaRaca (Raca r) {
		return this.racaRepository.save(r);
	}
	
	public Raca alteraRaca(JSONObject novaRaca) {
		Integer idRaca = novaRaca.getInt("idRaca");
		
		Raca racaAlterar = this.racaRepository.findByIdRaca(idRaca);
		racaAlterar.setDescricaoRaca(novaRaca.getString("descricaoRaca"));
		Categoria cat = this.categoriaRepository.findByIdCategoria(novaRaca.getInt("idCategoria"));
		racaAlterar.setCategoria(cat);
		
		return this.racaRepository.save(racaAlterar);
	}
	
	public Raca deletaRaca(Raca r) {
		return this.racaRepository.save(r);
	}
}
