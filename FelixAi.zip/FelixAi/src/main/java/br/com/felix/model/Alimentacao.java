package br.com.felix.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "felix_tb_alimentacao")
@SequenceGenerator(sequenceName = "sq_felix_tb_alimentacao", name = "alimentacao", allocationSize = 1)
public class Alimentacao {
	
	@Id
	@Column(name = "id_alimentacao")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "alimentacao")
	private int idAlimentacao;
	
	@Column(name = "desc_peso_porcao")
	private double pesoPorcao;
	
	@Column(name = "desc_vezes_servir")
	private int vezesServir;

	public Alimentacao() {
		
	}

	public int getIdAlimentacao() {
		return idAlimentacao;
	}

	public void setIdAlimentacao(int idAlimentacao) {
		this.idAlimentacao = idAlimentacao;
	}

	public double getPesoPorcao() {
		return pesoPorcao;
	}

	public void setPesoPorcao(double pesoPorcao) {
		this.pesoPorcao = pesoPorcao;
	}

	public int getVezesServir() {
		return vezesServir;
	}

	public void setVezesServir(int vezesServir) {
		this.vezesServir = vezesServir;
	}
	
	

}
