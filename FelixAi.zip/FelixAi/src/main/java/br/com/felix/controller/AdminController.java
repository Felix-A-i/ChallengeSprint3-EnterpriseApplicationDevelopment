package br.com.felix.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.felix.model.Dono;
import br.com.felix.model.Pet;
import br.com.felix.repository.AlimentacaoRepository;
import br.com.felix.repository.CategoriaRepository;
import br.com.felix.repository.DonoRepository;
import br.com.felix.repository.EnderecoRepository;
import br.com.felix.repository.PetRepository;
import br.com.felix.repository.PoteRepository;
import br.com.felix.repository.RacaRepository;
import br.com.felix.security.TokenService;

@Controller
public class AdminController {
	
	final String paginaDeslogado = "/paginas/index";
	
	@Autowired
	DonoRepository donoRepository;
	
	@Autowired
	AlimentacaoRepository alimentacaoRepository;
	
	@Autowired
	CategoriaRepository categoriaRepository;
	
	@Autowired
	PetRepository petRepository;
	
	@Autowired
	PoteRepository poteRepository;
	
	@Autowired
	RacaRepository racaRepository;
	
	@Autowired
	EnderecoRepository enderecoRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	TokenService tokenService;
	
	
	public boolean validaDonoLogado() {
		try {
			Object cli = session.getAttribute("idDono");
			Integer idCliente = Integer.parseInt(cli.toString());
			
			if(idCliente != null) {
				return true;
			}
		}catch(NullPointerException e) {}
		return false;
		
	}
	

	@RequestMapping(value="/",method=RequestMethod.GET)
	public String inicio() {
		
			return "/paginas/index";
		
	}
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String home(Model model) {
			
			if (this.validaDonoLogado()) {
				Integer idDono = Integer.parseInt(session.getAttribute("idDono").toString());
				Dono dono = this.donoRepository.findByIdDono(idDono);
				model.addAttribute("dono", dono);
				return "paginas/home";
			}else {
				return paginaDeslogado;
			}
			
	}
	@RequestMapping(value="/cadastro",method=RequestMethod.GET)
	public String cadastro() {
					
			return "paginas/cadastro";
	}
	
	@RequestMapping(value="/cadastro-pet",method=RequestMethod.GET)
	public String cadastroPet() {
		if (this.validaDonoLogado()) {
			return "paginas/cadastro-pet";
		}else {
			return paginaDeslogado;
		}
	}
	@RequestMapping(value="/listar-pet",method=RequestMethod.GET)
	public String listarPets(Model model) {
			
			if (this.validaDonoLogado()) {
				Integer idDono = Integer.parseInt(session.getAttribute("idDono").toString());
				Dono dono = this.donoRepository.findByIdDono(idDono);
				List<Pet> lst = this.petRepository.findByDono(dono);
				model.addAttribute("lst", lst);
				
				return "paginas/listar-pet";
			}else {
				return paginaDeslogado;
			}
			
	}
}