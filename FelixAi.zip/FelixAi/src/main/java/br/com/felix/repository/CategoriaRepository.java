package br.com.felix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Categoria;

public interface CategoriaRepository extends JpaRepository <Categoria, Integer>{
	
	Categoria findByIdCategoria (Integer idCategoria);
	Categoria findByDescricaoCategoria (String descCategoria);

}
