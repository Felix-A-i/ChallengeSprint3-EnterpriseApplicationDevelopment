package br.com.felix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Dono;
import br.com.felix.model.Pet;
import br.com.felix.model.Raca;

public interface PetRepository extends JpaRepository <Pet, Integer>{
	
	Pet findByIdPet (Integer idPet);
	List<Pet> findByDono (Dono dono);
	List<Pet> findByRaca (Raca raca);

}
