package br.com.felix.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "felix_tb_raca_pet")
@SequenceGenerator(sequenceName = "sq_felix_tb_raca_pet", name = "raca_pet", allocationSize = 1)
public class Raca {
	
	@Id
	@Column(name = "id_raca_pet")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "raca_pet")
	private int idRaca;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_categoria")
	private Categoria categoria;
	
	@Column(name = "desc_raca_pet")
	private String descricaoRaca;

	public Raca() {
	}

	public int getIdRaca() {
		return idRaca;
	}

	public void setIdRaca(int idRaca) {
		this.idRaca = idRaca;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public String getDescricaoRaca() {
		return descricaoRaca;
	}

	public void setDescricaoRaca(String descricaoRaca) {
		this.descricaoRaca = descricaoRaca;
	}
	
	
	
	
}
