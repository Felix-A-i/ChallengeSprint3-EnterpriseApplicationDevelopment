package br.com.felix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Pote;

public interface PoteRepository  extends JpaRepository <Pote, Integer>{
	
	Pote findByIdPote (Integer idPote);
	Pote findByCodigoPote (String codigoPote);

}
