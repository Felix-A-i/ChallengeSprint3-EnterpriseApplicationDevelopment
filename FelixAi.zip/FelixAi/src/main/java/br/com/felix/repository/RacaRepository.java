package br.com.felix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Categoria;
import br.com.felix.model.Raca;

public interface RacaRepository extends JpaRepository <Raca, Integer>{
		
	Raca findByIdRaca (Integer idRaca);
	Raca findByDescricaoRaca (String descricaoRaca);
	List <Raca> findByCategoria (Categoria categoria);
}
