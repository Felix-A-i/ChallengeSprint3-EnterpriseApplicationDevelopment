package br.com.felix.model;

public enum Hidratacao {
	
	VAZIO (1), CHEIO(2);
	
	public int hidratacao;
	
	Hidratacao(int hidrat) {
		hidratacao = hidrat;
	}
	public int getHidratacao() {
		return hidratacao;
	}
	
	

}
