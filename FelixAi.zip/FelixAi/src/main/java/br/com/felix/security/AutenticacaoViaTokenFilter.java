package br.com.felix.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import br.com.felix.model.Dono;
import br.com.felix.repository.DonoRepository;

public class AutenticacaoViaTokenFilter extends OncePerRequestFilter{
	
	private TokenService tokenService;
	private DonoRepository donoRepository;

	public AutenticacaoViaTokenFilter(TokenService tokenService, DonoRepository donoRepository) {
		this.tokenService = tokenService;
		this.donoRepository = donoRepository;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		String token = recuperarToken(request);
		boolean valido = tokenService.isTokenValido(token);
		if (valido) {
			autenticarDono(token);
		}
		
		filterChain.doFilter(request, response);
	}

	private void autenticarDono(String token) {
		Integer idDono = tokenService.getIdDono(token);
		Dono dono = donoRepository.findById(idDono).get();
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(dono, null, dono.getAuthorities());
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}

	private String recuperarToken(HttpServletRequest request) {
		String token = request.getHeader("Authorization");
		if (token == null || token.isEmpty() || !token.startsWith("Bearer ")) {
			return null;
		}
		
		return token.substring(7, token.length());
	}

}
