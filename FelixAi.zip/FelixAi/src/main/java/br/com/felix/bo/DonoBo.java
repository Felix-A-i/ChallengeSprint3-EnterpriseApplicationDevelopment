package br.com.felix.bo;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.validation.Valid;

import br.com.felix.dto.LoginDto;
import br.com.felix.model.Dono;
import br.com.felix.model.Endereco;
import br.com.felix.repository.DonoRepository;
import br.com.felix.repository.EnderecoRepository;
import net.sf.json.JSONObject;

public class DonoBo {

	private DonoRepository donoRepository;
	private EnderecoRepository enderecoRepository;
	
	public DonoBo(DonoRepository donoRepository, EnderecoRepository enderecoRepository) {
		this.donoRepository = donoRepository;
		this.enderecoRepository = enderecoRepository;
	}

	public Dono salvaDono(Dono d, Endereco e) {
		e = this.enderecoRepository.save(e);
		d.setEndereco(e);
		return this.donoRepository.save(d);
	}

	public Dono alteraDono(JSONObject novoDono) throws ParseException {
		Integer idDono = novoDono.getInt("idDono");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Dono donoAlterar = this.donoRepository.findByIdDono(idDono);
		donoAlterar.setCpf(novoDono.getString("cpf"));
		donoAlterar.setDataNascimento(sdf.parse(novoDono.getString("dataNasc")));
		
		Endereco e = new Endereco();
		e.setBairro(novoDono.getString("bairro"));
		e.setCidade(novoDono.getString("cidade"));
		e.setEstado(novoDono.getString("estado"));
		e.setLogradouro(novoDono.getString("logadouro"));
		e.setLogradouroNumero(novoDono.getInt("numeroLog"));
		e.setCep(novoDono.getString("cep"));
		
		donoAlterar.setEndereco(e);
		donoAlterar.setNomeDono(novoDono.getString("nomeDono"));

		return this.donoRepository.save(donoAlterar);

	}
	
	public JSONObject carregaDono(@Valid LoginDto form) {

		Dono dono = this.donoRepository.findByCpf(form.getCpf());
		JSONObject json = dono.toJsonSimple();

		return json;
	}

}
