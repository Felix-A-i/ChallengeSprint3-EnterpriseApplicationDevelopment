package br.com.felix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FelixAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FelixAiApplication.class, args);
	}

}
