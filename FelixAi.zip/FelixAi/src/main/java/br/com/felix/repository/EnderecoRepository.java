package br.com.felix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Endereco;

public interface EnderecoRepository extends JpaRepository <Endereco, Integer>{
	
	Endereco findByIdEndereco (Integer idEndereco);

}
