package br.com.felix.bo;

import java.util.ArrayList;
import java.util.List;

import br.com.felix.model.Alimentacao;
import br.com.felix.model.Dono;
import br.com.felix.model.Hidratacao;
import br.com.felix.model.Pote;
import br.com.felix.model.TamanhoPote;
import br.com.felix.repository.AlimentacaoRepository;
import br.com.felix.repository.DonoRepository;
import br.com.felix.repository.PoteRepository;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class PoteBo {
	
	private PoteRepository poteRepository;
	private DonoRepository donoRepository;
	private AlimentacaoRepository alimentacaoRepository;
	
	public PoteBo(PoteRepository poteRepository, DonoRepository donoRepository, AlimentacaoRepository alimentacaoRepository) {
		this.poteRepository = poteRepository;
		this.donoRepository = donoRepository;
		this.alimentacaoRepository = alimentacaoRepository;
	}
	
	public Pote salvaPote (Pote p) {
		return this.poteRepository.save(p);
	}
	
	public Pote alteraPote (JSONObject novoPote) {
		Integer idPote = novoPote.getInt("idPote");
		
		Pote poteAlterar = this.poteRepository.findByIdPote(idPote);
		poteAlterar.setCodigoPote(novoPote.getString("codigoPote"));
		Dono dono = donoRepository.findByIdDono(novoPote.getInt("idDono"));
		poteAlterar.setDono(dono);
		
		List <Alimentacao> lst = new ArrayList<Alimentacao>();
		
		JSONArray jArray = novoPote.getJSONArray("alimentacao");
		
		for (int i = 0; i < jArray.size(); i++) {
			JSONObject alimentacao = jArray.getJSONObject(i);
			
			Alimentacao alim = alimentacaoRepository.findByIdAlimentacao(alimentacao.getInt("idAlimentacao"));
			
			lst.add(alim);
		}
		poteAlterar.setAlimentacoes(lst);
		poteAlterar.setHidratacao((novoPote.getInt("hidratacao")== 1 ? Hidratacao.VAZIO : Hidratacao.CHEIO));
		
		TamanhoPote tamPote= null;
		if(novoPote.getInt("tamanhoPote") ==1) {
			tamPote = TamanhoPote.GRANDE;
		} else if(novoPote.getInt("tamanhoPote") ==2) {
			tamPote = TamanhoPote.MEDIO;
		}else if(novoPote.getInt("tamanhoPote") ==3) {
			tamPote = TamanhoPote.PEQUENO;
		}
		poteAlterar.setTamanhoPote(tamPote);
		
		return this.poteRepository.save(poteAlterar);
		
	}
}
