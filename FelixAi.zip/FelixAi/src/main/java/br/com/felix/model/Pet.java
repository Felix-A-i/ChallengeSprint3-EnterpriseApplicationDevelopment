package br.com.felix.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "felix_tb_pet")
@SequenceGenerator(sequenceName = "sq_felix_tb_pet", name = "pet", allocationSize = 1)
public class Pet {
	
	@Id
	@Column(name = "id_pet")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pet")
	private int idPet;
	
	@Column(name = "nm_pet")
	private String nome;
	
	@Column(name = "desc_peso_pet")
	private double peso;
	
	@Column(name = "dt_nasc_pet")
	private Date dtNascPet;
	
	@Column(name = "genero_pet")
	private GeneroPet genero;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_raca_pet")
	private Raca raca;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_categoria_pet")
	private Categoria categoria;
	
	@OneToOne
    @JoinColumn(name = "id_dono")
    private Dono dono;
	
	public Date getDtNascPet() {
		return dtNascPet;
	}

	public void setDtNascPet(Date dtNascPet) {
		this.dtNascPet = dtNascPet;
	}

	public GeneroPet getGenero() {
		return genero;
	}

	public void setGenero(GeneroPet genero) {
		this.genero = genero;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}

	

	public int getIdPet() {
		return idPet;
	}

	public void setIdPet(int idPet) {
		this.idPet = idPet;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public Raca getRaca() {
		return raca;
	}

	public void setRaca(Raca raca) {
		this.raca = raca;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

		
}