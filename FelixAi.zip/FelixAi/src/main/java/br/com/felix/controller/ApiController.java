package br.com.felix.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.felix.bo.DonoBo;
import br.com.felix.bo.PetBo;
import br.com.felix.model.Categoria;
import br.com.felix.model.Dono;
import br.com.felix.model.Endereco;
import br.com.felix.model.GeneroPet;
import br.com.felix.model.Pet;
import br.com.felix.model.Raca;
import br.com.felix.repository.AlimentacaoRepository;
import br.com.felix.repository.CategoriaRepository;
import br.com.felix.repository.DonoRepository;
import br.com.felix.repository.EnderecoRepository;
import br.com.felix.repository.PetRepository;
import br.com.felix.repository.PoteRepository;
import br.com.felix.repository.RacaRepository;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@RestController
@RequestMapping("/api")
public class ApiController {
	@Autowired
	DonoRepository donoRepository;
	
	@Autowired
	AlimentacaoRepository alimentacaoRepository;
	
	@Autowired
	CategoriaRepository categoriaRepository;
	
	@Autowired
	PetRepository petRepository;
	
	@Autowired
	PoteRepository poteRepository;
	
	@Autowired
	RacaRepository racaRepository;
	
	@Autowired
	EnderecoRepository enderecoRepository;
	
	@Autowired
	HttpSession session;
	
	public boolean validaDonoLogado() {
		try {
			Object dono = session.getAttribute("idDono");
			Integer idDono = Integer.parseInt(dono.toString());
			
			if(idDono != null) {
				return true;
			}
		}catch(NullPointerException e) {}
		return false;
		
	}
	@CrossOrigin
	@RequestMapping(value="/cadastro",method=RequestMethod.POST, produces = {"application/json"})
	public ResponseEntity<?> salvarDono(@RequestBody(required = true) JSONObject estruturaJson) throws Exception {
		JSONObject json = new JSONObject();
			Dono dono = new Dono();
			dono.setNomeDono(estruturaJson.getString("nomeDono"));
			dono.setCpf(estruturaJson.getString("cpf"));
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			dono.setDataNascimento(sdf.parse(estruturaJson.getString("dtNasc")));
			
			Endereco end = new Endereco();
			end.setLogradouro(estruturaJson.getString("logradouro"));
			end.setLogradouroNumero(estruturaJson.getInt("numeroLog"));
			end.setBairro(estruturaJson.getString("bairro"));
			end.setCidade(estruturaJson.getString("cidade"));
			end.setCep(estruturaJson.getString("cep"));
			end.setEstado(estruturaJson.getString("estado"));
			dono.setEndereco(end);
			
			String senha = new BCryptPasswordEncoder().encode(estruturaJson.getString("senha"));
			dono.setSenha(senha);
			
			try {
				DonoBo dBo = this.getInstanceDonoBo();
				Dono d = dBo.salvaDono(dono, end);
				json.put("erro", false);
			}catch (Exception e) {
				json.put("erro", true);
			}
				
			if(json.getBoolean("erro")) {
				return ResponseEntity.badRequest().body(json);
			}else {
				return ResponseEntity.ok(json);
			}
		
			
	}
	@CrossOrigin
	@RequestMapping(value="/cadastroPet",method=RequestMethod.POST, produces = {"application/json"})
	public ResponseEntity<?> salvarPet(@RequestBody(required = true) JSONObject estruturaJson) throws Exception {
		JSONObject json = new JSONObject();
			Pet pet = new Pet();
			Dono dono = this.donoRepository.findByIdDono(Integer.parseInt(session.getAttribute("idDono").toString()));
			pet.setDono(dono);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			pet.setDtNascPet(sdf.parse(estruturaJson.getString("dtNascPet")));
			
			pet.setGenero((estruturaJson.getInt("generoPet") == 1 ? GeneroPet.FEMEA : GeneroPet.MACHO));
			
			Categoria cat = this.categoriaRepository.findByIdCategoria(estruturaJson.getInt("idCategoria"));
			pet.setCategoria(cat);
			
			Raca raca = this.racaRepository.findByIdRaca(estruturaJson.getInt("idRaca"));
			pet.setRaca(raca);
			
			pet.setPeso(estruturaJson.getDouble("peso"));
			
			pet.setNome(estruturaJson.getString("nomePet"));
			
			try {
				PetBo pBo = this.getInstancePetBo();
				Pet p = pBo.salvarPet(pet);
				json.put("erro", false);
			}catch (Exception e) {
				json.put("erro", true);
			}
				
			if(json.getBoolean("erro")) {
				return ResponseEntity.badRequest().body(json);
			}else {
				return ResponseEntity.ok(json);
			}
			
	}
	
	@CrossOrigin
	@RequestMapping(value="/buscarRaca",method=RequestMethod.POST, produces = {"application/json"})
	public ResponseEntity<?> buscarRaca(@RequestBody(required = true) JSONObject estruturaJson) throws Exception {
		Categoria cat = this.categoriaRepository.findByIdCategoria(estruturaJson.getInt("categoria"));
		List <Raca> lraca = this.racaRepository.findByCategoria(cat);
		JSONArray jArray = new JSONArray();
		for (Raca raca : lraca) {
			JSONObject jsonRaca = new JSONObject(); 
			jsonRaca.put("idRaca", raca.getIdRaca());
			jsonRaca.put("descricaoRaca", raca.getDescricaoRaca());
			
			jArray.add(jsonRaca);
		} 
		
		return ResponseEntity.ok(jArray);
		
		
	}
	public DonoBo getInstanceDonoBo() {
		return new DonoBo(this.donoRepository, this.enderecoRepository);
	}
	public PetBo getInstancePetBo() {
		return new PetBo(this.petRepository, this.racaRepository, this.categoriaRepository, this.donoRepository);
	}
}
