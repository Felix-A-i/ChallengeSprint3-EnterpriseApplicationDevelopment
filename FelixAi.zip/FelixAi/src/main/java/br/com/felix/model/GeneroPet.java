package br.com.felix.model;

public enum GeneroPet {

	FEMEA (1), MACHO(2);
	
	public int genero;
	
	GeneroPet(int gen) {
		genero = gen;
	}
	public int getGenero() {
		return genero;
	}
}
