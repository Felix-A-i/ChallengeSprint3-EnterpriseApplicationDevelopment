package br.com.felix.model;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import net.sf.json.JSONObject;

@Entity
@Table(name = "felix_tb_dono_pet")
@SequenceGenerator(sequenceName = "sq_felix_tb_dono_pet", name = "dono_pet", allocationSize = 1)
public class Dono implements UserDetails{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id_dono")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dono_pet")
	private int idDono;
	
	@Column(name = "nm_dono")
	private String nomeDono;
	
	@Column(name = "cpf")
	private String cpf;
	
	@Column(name="senha")
	private String senha;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "dono")
    private List<Pet> pets;
	
	@Column(name = "dt_nasc")
	private Date dataNascimento;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_endereco_fk")
	private Endereco endereco;

	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "dono")
	private List<Perfil> perfis;

	public int getIdDono() {
		return idDono;
	}

	public void setIdDono(int idDono) {
		this.idDono = idDono;
	}

	public String getNomeDono() {
		return nomeDono;
	}

	public void setNomeDono(String nomeDono) {
		this.nomeDono = nomeDono;
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public List<Pet> getPets() {
		return pets;
	}

	public void setPets(List<Pet> pets) {
		this.pets = pets;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public JSONObject toJsonSimple() {
		JSONObject json = new JSONObject();
		json.put("idDono", this.idDono);
		json.put("nomeDono", this.nomeDono);
		json.put("cpf", this.cpf);
		
		return json;
	}

	public List<Perfil> getPerfis() {
		return perfis;
	}

	public void setPerfis(List<Perfil> perfis) {
		this.perfis = perfis;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.getPerfis();
	}

	@Override
	public String getPassword() {
		return this.senha;
	}

	@Override
	public String getUsername() {
		return this.cpf;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}
