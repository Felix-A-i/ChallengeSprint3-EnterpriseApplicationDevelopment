package br.com.felix.bo;

import br.com.felix.model.Alimentacao;
import br.com.felix.repository.AlimentacaoRepository;
import net.sf.json.JSONObject;

public class AlimentacaoBo {

	private AlimentacaoRepository alimentacaoRepository;
	
	public AlimentacaoBo(AlimentacaoRepository alimentacaoRepository) {
		this.alimentacaoRepository = alimentacaoRepository;
	}
	
	public Alimentacao salvarAlimentacao (Alimentacao a) {
		return this.alimentacaoRepository.save(a);
	}
	
	public Alimentacao alteraAlimentacao(JSONObject novaAlimentacao) {
		Integer idAlimentacao = novaAlimentacao.getInt("idAlimentacao");
		
		Alimentacao alimentacaoAlterar = this.alimentacaoRepository.findByIdAlimentacao(idAlimentacao);
		alimentacaoAlterar.setPesoPorcao(novaAlimentacao.getDouble("pesoAlimentacao"));
		alimentacaoAlterar.setVezesServir(novaAlimentacao.getInt("vezesServir"));
		
		return this.alimentacaoRepository.save(alimentacaoAlterar);
	}
	
	public void deletarAlimentacao (Alimentacao a) {
		this.alimentacaoRepository.delete(a);
	}
}
