package br.com.felix.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "felix_tb_categoria_pet")
@SequenceGenerator(sequenceName = "sq_felix_tb_categoria_pet", name = "categoria_pet", allocationSize = 1)
public class Categoria {
	
	@Id
	@Column(name = "id_categoria")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "categoria_pet")
	private int idCategoria;
	
	@Column(name = "desc_categoria")
	private String descricaoCategoria;

	public Categoria() {
	}

	public String getDescricaoCategoria() {
		return descricaoCategoria;
	}

	public void setDescricaoCategoria(String descricaoCategoria) {
		this.descricaoCategoria = descricaoCategoria;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	

}
