package br.com.felix.bo;

import br.com.felix.model.Categoria;
import br.com.felix.repository.CategoriaRepository;
import net.sf.json.JSONObject;

public class CategoriaBo {
	
	private CategoriaRepository categoriaRepository;
	
	public CategoriaBo(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}
	
	public Categoria salvarCategoria(Categoria c) {
		return this.categoriaRepository.save(c);
	}
	
	public Categoria alteraCategoria (JSONObject novaCategoria) {
		Integer idCategoria = novaCategoria.getInt("idCategoria");
		
		Categoria categoriaAlterar = this.categoriaRepository.findByIdCategoria(idCategoria);
		categoriaAlterar.setDescricaoCategoria("descricaoCategoria");
		
		return this.categoriaRepository.save(categoriaAlterar);
		
	}
	
	public void deletarCategoria(Categoria c) {
		this.categoriaRepository.delete(c);
	}

}
