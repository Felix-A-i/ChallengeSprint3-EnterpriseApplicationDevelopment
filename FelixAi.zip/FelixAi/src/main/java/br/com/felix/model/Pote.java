package br.com.felix.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "felix_tb_pote")
@SequenceGenerator(sequenceName = "sq_felix_tb_pote", name = "pote", allocationSize = 1)
public class Pote {
	
	@Id
	@Column(name = "id_pote")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pote")
	private int idPote;
	
	@Column(name = "codigo_pote")
	private String codigoPote;
	
	@Column(name = "tamanho_pote")
	private TamanhoPote tamanhoPote;
	
	@OneToMany
    @JoinColumn(name = "id_alimentacao")
    private List<Alimentacao> alimentacoes;
	
	@Column(name = "hidratacao")
	private Hidratacao hidratacao;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_dono")
	private Dono dono;

	public int getIdPote() {
		return idPote;
	}

	public void setIdPote(int idPote) {
		this.idPote = idPote;
	}

	public String getCodigoPote() {
		return codigoPote;
	}

	public void setCodigoPote(String codigoPote) {
		this.codigoPote = codigoPote;
	}

	public TamanhoPote getTamanhoPote() {
		return tamanhoPote;
	}

	public void setTamanhoPote(TamanhoPote tamanhoPote) {
		this.tamanhoPote = tamanhoPote;
	}

	public List<Alimentacao> getAlimentacoes() {
		return alimentacoes;
	}

	public void setAlimentacoes(List<Alimentacao> alimentacoes) {
		this.alimentacoes = alimentacoes;
	}

	public Hidratacao getHidratacao() {
		return hidratacao;
	}

	public void setHidratacao(Hidratacao hidratacao) {
		this.hidratacao = hidratacao;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}
	
	
}
