package br.com.felix.model;

public enum TamanhoPote {
	
	GRANDE (1), MEDIO(2), PEQUENO(3);
	
	public int tamanhoPote;
	
	TamanhoPote(int pote) {
		tamanhoPote = pote;
	}
	public int getTamanhoPote() {
		return tamanhoPote;
	}

}
