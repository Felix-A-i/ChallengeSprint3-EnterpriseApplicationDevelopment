package br.com.felix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Dono;

public interface DonoRepository extends JpaRepository <Dono, Integer>{
	
	Dono findByIdDono (Integer idDono);
	Dono findByCpf (String cpf);

}
