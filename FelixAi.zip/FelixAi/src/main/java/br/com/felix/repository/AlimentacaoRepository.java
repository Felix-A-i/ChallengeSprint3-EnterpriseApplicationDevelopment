package br.com.felix.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.felix.model.Alimentacao;

public interface AlimentacaoRepository extends JpaRepository <Alimentacao, Integer>{
	
	Alimentacao findByIdAlimentacao (Integer idAlimentacao);

}
