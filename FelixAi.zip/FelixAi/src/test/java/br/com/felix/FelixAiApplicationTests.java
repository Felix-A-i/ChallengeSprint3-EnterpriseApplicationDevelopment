package br.com.felix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FelixAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
